import React, { useState } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import './registrationForm.css';
import axios from 'axios';

const RegistrationForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        rollNumber: '',
        college: '',
        phone: '',
        otp: ''
    });

    const [otpSent, setOtpSent] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSendOTP = () => {
        if (!formData.phone) {
            toast.error('Please enter a phone number before sending OTP');
            return;
        }

        // Simulate OTP send
        console.log(`Sending OTP to ${formData.phone}`);

        try {
            const fun = async () => {
                const response = await axios.post("http://localhost:3001/send-otp", {
                    phone: formData.phone
                });
                console.log(response);
            }
            fun();
            toast.success('OTP sent successfully!');
            setOtpSent(true);
        }
        catch(e) {
            toast.error('Failed to send OTP');
        }
        
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!otpSent) {
            toast.error('Please verify your phone number by entering the OTP');
            return;
        }

        // Simulate form submission
        console.log('Form Data:', formData);

        const fun = async () => {
            const response = await axios.post("http://localhost:3001/validate-otp", {
                phone: formData.phone
            });
            console.log(response);
        }
        fun();


        toast.success('Registration submitted successfully!');

        // Reset the form fields
        setFormData({
            name: '',
            rollNumber: '',
            college: '',
            phone: '',
            otp: ''
        });
        setOtpSent(false);
    };

    return (
        <>
            <Toaster position="top-center" reverseOrder={false} />
            <div className="headForContact">
                <span className="sectionTitle__small">
                    <i className="fa-solid fa-user btn__icon"></i>
                    Registration
                </span>
                <h2>Fill Your Details</h2>
            </div>
            <div className="form-container">
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Name:</label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Roll Number:</label>
                        <input
                            type="text"
                            name="rollNumber"
                            value={formData.rollNumber}
                            onChange={handleChange}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>College:</label>
                        <input
                            type="text"
                            name="college"
                            value={formData.college}
                            onChange={handleChange}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Phone Number:</label>
                        <div style={{ display: 'flex', alignItems: 'center' }}>
                            <input
                                type="tel"
                                name="phone"
                                value={formData.phone}
                                onChange={handleChange}
                                required
                                style={{ flex: 1 }}
                            />
                            <button
                                type="button"
                                onClick={handleSendOTP}
                                className="otp-button"
                            >
                                Send OTP
                            </button>

                        </div>
                    </div>

                    {otpSent && (
                        <div className="form-group">
                            <label>Enter OTP:</label>
                            <input
                                type="text"
                                name="otp"
                                value={formData.otp}
                                onChange={handleChange}
                                required
                            />
                        </div>
                    )}

                    <button type="submit">Submit</button>
                </form>
            </div>
        </>
    );
};

export default RegistrationForm;
